package com.lg.NocBlog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NocBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
